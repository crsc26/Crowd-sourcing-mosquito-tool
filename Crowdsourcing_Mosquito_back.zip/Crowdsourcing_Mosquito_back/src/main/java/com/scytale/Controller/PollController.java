package com.scytale.Controller;

import com.scytale.DAO.AvistamientoDAO;
import com.scytale.DAO.PollDAO;
import com.scytale.Entity.Avistamiento;
import com.scytale.Entity.Poll;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;


@Controller
@RequestMapping(
        path = {"/poll"}
        )
public class PollController {

    @Autowired
    private PollDAO pollDAO;

    @CrossOrigin
    @GetMapping(
            path = "/vote"
    )
    public @ResponseBody
    void getContrib(@RequestParam String username, String type, int poll ) {
        System.out.println(poll);
        System.out.println(username);
        System.out.println(type);

        Poll p = pollDAO.findById(poll);
        if (type.equals("yes")) {
            p.setPositive_votes(p.getPositive_votes() + 1);
        } else {
            if (type.equals("culex")) {
                p.setCulex(p.getCulex() + 1);
            } else if (type.equals("anopheles")) {
                p.setAnopheles(p.getAnopheles() + 1);
            } else if (type.equals("aedes")) {
                p.setAedes(p.getAedes() + 1);
            } else if (type.equals("other")) {
                p.setOther(p.getOther() + 1);
            }

        }
        pollDAO.save(p);

    }

}
