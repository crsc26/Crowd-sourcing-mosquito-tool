package com.scytale.Controller;


import com.scytale.DAO.AvistamientoDAO;
import com.scytale.DAO.PollDAO;
import com.scytale.Entity.Avistamiento;
import com.scytale.Entity.Poll;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

@Controller
@RequestMapping(
        path = {"/seen"}
)
public class AvistamientoController {
    @Autowired
    private AvistamientoDAO avistamientoDAO;
    @Autowired
    private PollDAO pollDAO;

    public AvistamientoController(){}

    @CrossOrigin
    @GetMapping(
            path = "/getAll"
    )
    @ResponseBody
    public String getAll() {

        Iterable<Avistamiento> arr = avistamientoDAO.findAll();
        Iterator<Avistamiento> itr = arr.iterator();

        JSONArray result = new JSONArray();

        while(itr.hasNext()){
            Avistamiento a = itr.next();
            JSONObject obj = new JSONObject();

            try {
                obj.put("Type", a.getTipo());
                obj.put("Coordenates", a.getCoordenadas().replace(',', ';'));
                obj.put("Seen", a.getAvistamiento());
                obj.put("Temperature", a.getTemperatura());
                obj.put("Comment", a.getComentario());
                obj.put("User", a.getUsuario());
                result.put(obj);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        return result.toString();
    }

    @CrossOrigin
    @GetMapping(
            path = "/getContrib"
    )
    public @ResponseBody
    String getContrib(@RequestParam String username ) {
        System.out.println(username);

        ArrayList<Avistamiento> response = avistamientoDAO.findByUsuario(username);
        Iterator<Avistamiento> itr = response.iterator();

        JSONArray result = new JSONArray();

        while(itr.hasNext()){
            Avistamiento a = itr.next();
            JSONObject obj = new JSONObject();

            try {
                obj.put("Tipo", a.getTipo());
                obj.put("Coordenadas", a.getCoordenadas());
                obj.put("Avistamiento", a.getAvistamiento());
                obj.put("Temperatura", a.getTemperatura());
                obj.put("Comentario", a.getComentario());
                result.put(obj);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        System.out.println(response.size());

        return result.toString();

    }

    @CrossOrigin
    @GetMapping(
            path = "/find"
    )
    public @ResponseBody
    String findByCoor(@RequestParam String coordenates ) {
        System.out.println(coordenates);

       Avistamiento a = avistamientoDAO.findByCoordenadas(coordenates);
       JSONObject obj = new JSONObject();
        try {
            obj.put("Tipo", a.getTipo());
            obj.put("Coordenadas", a.getCoordenadas());
            obj.put("Avistamiento", a.getAvistamiento());
            obj.put("Temperatura", a.getTemperatura());
            obj.put("Comentario", a.getComentario());
            obj.put("User", a.getUsuario());
            obj.put("Photo", a.getPhotoUrl());
            obj.put("Poll", a.getPoll());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return obj.toString();

    }

    @RequestMapping(
            value = "/postAdd",
            method = RequestMethod.POST,
            consumes = "text/plain")
    public void process(@RequestBody String payload) throws Exception {
        JSONObject obj = new JSONObject(payload);

        JSONObject img = obj.getJSONObject("img");
        String filename = img.getString("filename");

        String imageString = img.getString("base64");


        /*BufferedImage photo = ImageIO.read(new ByteArrayInputStream(imageBytes));
        File outputfile = new File("C:/Users/eqc_9/Desktop/" + filename);
        ImageIO.write(photo, "jpg", outputfile);*/



        Avistamiento a = new Avistamiento();
        a.setAvistamiento(obj.getString("seen"));
        a.setComentario(obj.getString("comments"));
        a.setCoordenadas(obj.getString("coordenadas"));
        a.setTemperatura(obj.getString("temp"));
        a.setTipo(obj.getString("type"));
        a.setUsuario(obj.getString("user"));
        a.setPhotoUrl(imageString);

        Poll p = new Poll();

        this.pollDAO.save(p);
        a.setPoll(p);

        this.avistamientoDAO.save(a);

        System.out.println(payload);
    }

}
