package com.scytale.Entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="encuesta")
public class Poll {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @NotNull
    private int culex = 0;

    @NotNull
    private int aedes = 0;

    @NotNull
    private int anopheles = 0;

    @NotNull
    private int other = 0;

    @NotNull
    private int positive_votes = 0;

    @OneToOne(fetch = FetchType.LAZY)
    @PrimaryKeyJoinColumn
    private Avistamiento avistamiento;

    public Integer getId() {
        return id;
    }

    public int getCulex() {
        return culex;
    }

    public void setCulex(int culex) {
        this.culex = culex;
    }

    public int getAedes() {
        return aedes;
    }

    public void setAedes(int aedes) {
        this.aedes = aedes;
    }

    public int getAnopheles() {
        return anopheles;
    }

    public void setAnopheles(int anopheles) {
        this.anopheles = anopheles;
    }

    public int getOther() {
        return other;
    }

    public void setOther(int other) {
        this.other = other;
    }

    public Avistamiento getAvistamiento() {
        return avistamiento;
    }

    public void setAvistamiento(Avistamiento avistamiento) {
        this.avistamiento = avistamiento;
    }

    public int getPositive_votes() {
        return positive_votes;
    }

    public void setPositive_votes(int positive_votes) {
        this.positive_votes = positive_votes;
    }

    public int getNegativeVotes(){
        return this.culex + this.aedes + this.anopheles + this.other;
    }




}
