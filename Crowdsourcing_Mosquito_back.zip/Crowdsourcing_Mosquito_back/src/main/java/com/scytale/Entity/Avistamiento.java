/*This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. */

package com.scytale.Entity;

import org.hibernate.annotations.NaturalId;
import org.json.JSONException;
import org.json.JSONObject;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.lang.reflect.Array;
import java.util.Set;
import java.util.Set;

@Entity
@Table(name="avistamientos")
public class Avistamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @NotNull
    private String coordenadas;

    @NotNull
    private String tipo;

    @NotNull
    private String avistamiento;

    @NotNull
    private String temperatura;

    @NotNull
    private String comentario;

    @NotNull
    private String usuario;

    private String photoUrl;

    @NotNull
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "encuesta_id")
    private Poll poll;



    public Integer getId() {
        return id;
    }

    public String getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(String coordenadas) {
        this.coordenadas = coordenadas;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAvistamiento() {
        return avistamiento;
    }

    public void setAvistamiento(String avistamiento) {
        this.avistamiento = avistamiento;
    }

    public String getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(String temperatura) {
        this.temperatura = temperatura;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getUsuario() {
        return usuario;
    }


    public JSONObject getPoll() {
        JSONObject o = new JSONObject();

        try {
            o.put("aedes", this.poll.getAedes());
            o.put("anopheles", this.poll.getAnopheles());
            o.put("culex", this.poll.getCulex());
            o.put("other", this.poll.getOther());
            o.put("positive", this.poll.getPositive_votes());
            o.put("poll", this.poll.getId());
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return o;
    }

    public void setPoll(Poll poll) {
        this.poll = poll;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

}
