package com.scytale.DAO;


import com.scytale.Entity.Poll;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;

public interface PollDAO extends CrudRepository<Poll, Long> {
    @Transactional
    Poll findById(int id);
}
